Universal File Viewer 压缩包中文预览验证
支持多级目录，并可打开实际文件。
